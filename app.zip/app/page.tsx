"use client";

import Link from "next/link";
import React, { useEffect, useMemo, useRef, useState } from "react";


function useIsMobile(breakpoint: number = 768) {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const mq = window.matchMedia(`(max-width: ${breakpoint}px)`);
    const onChange = () => setIsMobile(mq.matches);

    onChange();

    // Safari fallback
    if (typeof mq.addEventListener === "function") {
      mq.addEventListener("change", onChange);
      return () => mq.removeEventListener("change", onChange);
    }

    const legacyMq = mq as any;
    legacyMq.addListener?.(onChange);
    return () => legacyMq.removeListener?.(onChange);
  }, [breakpoint]);

  return isMobile;
}


function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(mq.matches);
    onChange();
    if (typeof mq.addEventListener === "function") {
      mq.addEventListener("change", onChange);
      return () => mq.removeEventListener("change", onChange);
    }
    const legacyMq = mq as any;
    legacyMq.addListener?.(onChange);
    return () => legacyMq.removeListener?.(onChange);
  }, []);
  return reduced;
}

function useIsCoarsePointer() {
  const [coarse, setCoarse] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;
    const mq = window.matchMedia("(pointer: coarse)");
    const onChange = () => setCoarse(mq.matches);
    onChange();
    if (typeof mq.addEventListener === "function") {
      mq.addEventListener("change", onChange);
      return () => mq.removeEventListener("change", onChange);
    }
    const legacyMq = mq as any;
    legacyMq.addListener?.(onChange);
    return () => legacyMq.removeListener?.(onChange);
  }, []);
  return coarse;
}

type SmartImgProps = {
  baseSrc: string;
  alt: string;
  style?: React.CSSProperties;
  className?: string;
  loading?: "eager" | "lazy";
  fetchPriority?: "high" | "low" | "auto";
  onLoad?: () => void;
};;

function SmartImg({ baseSrc, alt, style, className, loading = "lazy", fetchPriority = "auto", onLoad }: SmartImgProps) {
  const safeBaseSrc = String((baseSrc as any) ?? "");
  // ✅ Soporta archivos SIN extensión (por ejemplo: /home/stories/story-01)
  // y también con extensión normal (/home/stories/story-01.jpg).
  const hasExt = useMemo(() => /\.[a-zA-Z0-9]+$/.test(safeBaseSrc), [safeBaseSrc]);

  // Cuando NO hay extensión, primero probamos el baseSrc "tal cual"
  // (sirve si el archivo real en /public no tiene extensión).
  const candidates = useMemo(() => {
    if (!safeBaseSrc) return [];
    // Si ya trae extensión, úsalo tal cual. Si no, usamos .jpg (nuestras imágenes del repo).
    if (hasExt) return [safeBaseSrc];
    return [`${safeBaseSrc}.jpg`];
  }, [safeBaseSrc, hasExt]);

  const [idx, setIdx] = useState(0);

  // Resetea el índice si cambia la imagen
  useEffect(() => {
    setIdx(0);
  }, [safeBaseSrc]);

  const src = candidates[Math.min(idx, candidates.length - 1)];

  return (
    <img
      src={src}
      alt={alt}
      className={className}
      style={style}
      loading={loading}
      decoding="async"
      fetchPriority={fetchPriority}
      onLoad={onLoad}
      onError={() => {
        if (idx < candidates.length - 1) setIdx((i) => Math.min(i + 1, candidates.length - 1));
      }}
    />
  );



}


type TopItem = {
  id: string;
  name: string;
  href: string;
  imgBase: string;
  img?: string;
  brand?: string;
  price?: string;
};

const TOP_ITEMS: TopItem[] = [
  { id: "t1", name: "Air Max", href: "/products?tag=top&pick=01", imgBase: "/home/mas-top/01", brand: "Nike", price: "Drop Top" },
  { id: "t2", name: "Superstar", href: "/products?tag=top&pick=02", imgBase: "/home/mas-top/02", brand: "Adidas", price: "Drop Top" },
  { id: "t3", name: "Jordan Low", href: "/products?tag=top&pick=03", imgBase: "/home/mas-top/03", brand: "Jordan", price: "Drop Top" },
  { id: "t4", name: "Air Force 1", href: "/products?tag=top&pick=04", imgBase: "/home/mas-top/04", brand: "Nike", price: "Drop Top" },
  { id: "t5", name: "Dunk Low", href: "/products?tag=top&pick=05", imgBase: "/home/mas-top/05", brand: "Nike", price: "Drop Top" },
  { id: "t6", name: "Campus", href: "/products?tag=top&pick=06", imgBase: "/home/mas-top/06", brand: "Adidas", price: "Drop Top" },
  { id: "t7", name: "Tech Fleece", href: "/products?tag=top&pick=07", imgBase: "/home/mas-top/07", brand: "Nike", price: "Drop Top" },
  { id: "t8", name: "Essentials", href: "/products?tag=top&pick=08", imgBase: "/home/mas-top/08", brand: "Fear of God", price: "Drop Top" },
  { id: "t9", name: "Running", href: "/products?tag=top&pick=09", imgBase: "/home/mas-top/09", brand: "Nike", price: "Drop Top" },
  { id: "t10", name: "Metcon", href: "/products?tag=top&pick=10", imgBase: "/home/mas-top/10", brand: "Nike", price: "Drop Top" },
];

const ALL_PRODUCTS: TopItem[] = TOP_ITEMS.map((t, idx) => ({
  ...t,
  id: `p${idx + 1}`,
  price: t.price ?? "Oferta",
}));


type CardItem = {
  id?: string;
  kicker?: string;
  title: string;
  desc?: string;
  href?: string;
  img?: string;
  links?: Array<{ label: string; href: string }>;
};

type PrefFocus = "hombre" | "mujer" | "ninos" | "mix";

type UserSession = {
  email: string;
  name?: string;
  createdAt: number;
  lastSeenAt: number;
  hasPurchased?: boolean;
  onboardingDone?: boolean;
  prefs?: { focus?: PrefFocus; sizes?: string[]; interests?: string[] };
};

type SearchItem = { id: string; name: string; href: string; img: string; brand?: string };

/* ==========================
   TOP PICKS · UI HELPERS
   ========================== */

const SAVED_TOP_KEY = "jusp_saved_top_picks_v1";

function useLocalStorageStringArray(key: string) {
  const [value, setValue] = useState<string[]>([]);
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) setValue(parsed.map(String));
      }
    } catch {}
  }, [key]);

  const save = (next: string[]) => {
    setValue(next);
    try {
      window.localStorage.setItem(key, JSON.stringify(next));
    } catch {}
  };

  return [value, save] as const;
}

function TopPickMedia({ baseSrc, alt, active }: { baseSrc: string; alt: string; active: boolean }) {
  const isMobile = useIsMobile();

  // Smooth cross-fade / soften transform when the media changes (mobile felt "forced").
  const [ready, setReady] = React.useState(false);
  React.useEffect(() => {
    setReady(false);
    const id = requestAnimationFrame(() => setReady(true));
    return () => cancelAnimationFrame(id);
  }, [baseSrc]);

  const softMotion = isMobile;

  const wrapStyle: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    borderRadius: 24,
    overflow: "hidden",
    transformStyle: "preserve-3d",
    backfaceVisibility: "hidden",
    willChange: "transform, opacity",
    transitionProperty: "transform, opacity",
    transitionDuration: softMotion ? "520ms" : "600ms",
    transitionTimingFunction: "cubic-bezier(0.22, 1, 0.36, 1)",
    transformOrigin: "50% 60%",
    opacity: active ? 1 : 0,
    transform: active
      ? softMotion
        ? "translate3d(0,-1px,0) scale(1)"
        : "perspective(900px) translateZ(0) rotateX(2deg) rotateY(-6deg) translateY(-2px) scale(1)"
      : softMotion
        ? "translate3d(0,10px,0) scale(0.992)"
        : "perspective(900px) translateZ(0) rotateX(0deg) rotateY(0deg) translateY(10px) scale(0.985)",
  };

  // Separate layer for the actual image to fade-in on change (prevents hard "snap").
  const imgLayerStyle: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    opacity: ready ? 1 : 0,
    transform: ready ? "translate3d(0,0,0) scale(1)" : "translate3d(0,8px,0) scale(0.995)",
    transitionProperty: "opacity, transform",
    transitionDuration: softMotion ? "420ms" : "480ms",
    transitionTimingFunction: "cubic-bezier(0.22, 1, 0.36, 1)",
    willChange: "opacity, transform",
  };

  return (
    <div style={wrapStyle} aria-hidden={!active}>
      <div style={imgLayerStyle}>
        <SmartImg
          key={baseSrc}
          baseSrc={baseSrc}
          alt={alt}
          style={{ width: "100%", height: "100%", objectFit: "contain", display: "block", transform: "scale(0.94)", transformOrigin: "center" }}
/>
      </div>
    </div>
  );
}


function SaveTopButton({
  id,
  saved,
  onToggle,
}: {
  id: string;
  saved: boolean;
  onToggle: (id: string) => void;
}) {
  return (
    <button
      type="button" className="jusp-btn jusp-save jusp-focus"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onToggle(id);
      }}
      style={{
        appearance: "none",
        border: "1px solid rgba(255,255,255,0.22)",
        background: saved ? "rgba(255,255,255,0.95)" : "rgba(0,0,0,0.30)",
        color: saved ? "#000" : "#fff",
        borderRadius: 999,
        padding: "9px 12px",
        fontSize: 12,
        fontWeight: 900,
        cursor: "pointer",
        backdropFilter: "blur(10px)",
      }}
      aria-label={saved ? "Guardado" : "Guardar"}
      title={saved ? "Guardado" : "Guardar"}
      data-saved={saved ? "1" : "0"}
    >
      {saved ? "Guardado" : "Guardar"}
    </button>
  );
}


export default function Page() {
  const scrollToTopPicks = () => {
    const section = document.getElementById("top-picks");
    if (!section) return;
    const y = section.getBoundingClientRect().top + window.scrollY - 96;
    window.scrollTo({ top: y, behavior: "smooth" });
    if (typeof window !== "undefined" && window.location.hash) {
      try {
        window.history.replaceState(null, "", window.location.pathname + window.location.search);
      } catch {}
    }
  };

  
  const [savedTopIds, setSavedTopIds] = useLocalStorageStringArray(SAVED_TOP_KEY);

  const [topQuery, setTopQuery] = useState("");
  const TOP_CHIPS = useMemo(() => ["Nike", "Jordan", "Adidas", "Dunk", "Air Max", "Tech Fleece"], []);
  const runTopSearch = (q: string) => {
    const query = (q || "").trim();
    if (!query) return;
    if (typeof window === "undefined") return;
    window.location.assign(`/products?q=${encodeURIComponent(query)}`);
  };

  const isMobile = useIsMobile();
  const reduceMotion = usePrefersReducedMotion();

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      if ("scrollRestoration" in window.history) {
        window.history.scrollRestoration = "manual";
      }
    } catch {}
    window.scrollTo(0, 0);
  }, []);

  /* ==========================
     BLOQUE 1 · HERO (2 VIDEOS)
     ========================= */
  const videos = ["/home/video/hero-1.mp4", "/home/video/hero-2.mp4"];
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [videoIndex, setVideoIndex] = useState(0);
  const onHeroEnded = () => setVideoIndex((prev) => (prev + 1) % videos.length);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const tryPlay = () => v.play().catch(() => {});
    v.load();
    tryPlay();
    v.addEventListener("loadeddata", tryPlay);
    v.addEventListener("canplay", tryPlay);
    return () => {
      v.removeEventListener("loadeddata", tryPlay);
      v.removeEventListener("canplay", tryPlay);
    };
  }, [videoIndex]);

  /* ==========================================
     BLOQUE 2 · LO MÁS TOP (CARRUSEL PRO MAX)
     ========================================== */
  const topItems = TOP_ITEMS;

  /* ==========================================
     SEARCH PRO MAX
     ========================================== */
  const SEARCH_RECENTS_KEY = "jusp_home_search_recents_v1";
  const USER_KEY = "jusp_user_v1";
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState("");
  const [searchRecents, setSearchRecents] = useState<string[]>([]);
  const [searchResults, setSearchResults] = useState<SearchItem[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const cacheRef = useRef<Map<string, SearchItem[]>>(new Map());
  const lastQueryRef = useRef<string>("");

  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [user, setUser] = useState<UserSession | null>(null);
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authErr, setAuthErr] = useState<string | null>(null);

  const [onboardingStep, setOnboardingStep] = useState<0 | 1 | 2>(0);
  const [prefFocus, setPrefFocus] = useState<PrefFocus>("mix");
  const [prefSizes, setPrefSizes] = useState<string[]>([]);
  const [prefInterests, setPrefInterests] = useState<string[]>([]);

  /* ==========================================
     NEWSLETTER (Nike-style)
     ========================================== */
  const NL_HIDE_KEY = "jusp_newsletter_hide_until_v1";
  const NL_SUB_KEY = "jusp_newsletter_subscribed_v1";
  const [nlOpen, setNlOpen] = useState(false);
  const [nlEmail, setNlEmail] = useState("");
  const [nlStatus, setNlStatus] = useState<"idle" | "loading" | "ok" | "error">("idle");
  const [nlMsg, setNlMsg] = useState<string>("");
  const [nlSubscribed, setNlSubscribed] = useState(false);

  function isValidEmail(v: string) {
    const s = String(v || "").trim();
    if (!s) return false;
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(s);
  }

  function readHideUntil(): number {
    try {
      const raw = localStorage.getItem(NL_HIDE_KEY);
      const n = Number(raw);
      return Number.isFinite(n) ? n : 0;
    } catch {
      return 0;
    }
  }

  function writeHideDays(days: number) {
    try {
      const until = Date.now() + days * 24 * 60 * 60 * 1000;
      localStorage.setItem(NL_HIDE_KEY, String(until));
    } catch {}
  }

  function writeSubscribed() {
    try {
      localStorage.setItem(NL_SUB_KEY, "1");
    } catch {}
  }

  useEffect(() => {
    try {
      const isSub = localStorage.getItem(NL_SUB_KEY) === "1";
      setNlSubscribed(isSub);
      const hideUntil = readHideUntil();
      const shouldHide = hideUntil && Date.now() < hideUntil;
      if (!isSub && !shouldHide) {
        const t = window.setTimeout(() => setNlOpen(true), 900);
        return () => window.clearTimeout(t);
      }
    } catch {
      const t = window.setTimeout(() => setNlOpen(true), 900);
      return () => window.clearTimeout(t);
    }
  }, []);

  function closeNewsletter() {
    setNlOpen(false);
    setNlMsg("");
    setNlStatus("idle");
    writeHideDays(30);
  }

  async function onNewsletterSubmit(e: React.FormEvent) {
    e.preventDefault();
    const email = nlEmail.trim();
    setNlMsg("");
    if (!isValidEmail(email)) {
      setNlStatus("error");
      setNlMsg("Escribe un correo válido (ej: hola@correo.com).");
      return;
    }
    setNlStatus("loading");
    try {
      const res = await fetch("/api/marketing/subscribe", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, source: "newsletter_modal", ts: Date.now() }),
      });
      if (!res.ok) {
        const txt = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status} ${txt}`.trim());
      }
      setNlStatus("ok");
      setNlMsg("Listo ✅ Te avisaremos cuando haya drops y descuentos.");
      setNlEmail("");
      setNlSubscribed(true);
      writeSubscribed();
      window.setTimeout(() => setNlOpen(false), 900);
    } catch {
      setNlStatus("error");
      setNlMsg("No se pudo registrar ahora. Intenta de nuevo en unos segundos.");
    }
  }

  const safeLoadRecents = () => {
    try {
      const raw = localStorage.getItem(SEARCH_RECENTS_KEY);
      if (!raw) return [];
      const arr = JSON.parse(raw);
      if (!Array.isArray(arr)) return [];
      return arr.filter((x) => typeof x === "string").slice(0, 8);
    } catch {
      return [];
    }
  };

  const safeSaveRecent = (text: string) => {
    const s = text.trim();
    if (!s) return;
    try {
      const prev = safeLoadRecents();
      const next = [s, ...prev.filter((x) => x.toLowerCase() !== s.toLowerCase())].slice(0, 8);
      localStorage.setItem(SEARCH_RECENTS_KEY, JSON.stringify(next));
      setSearchRecents(next);
    } catch {}
  };

  const safeLoadUser = (): UserSession | null => {
    try {
      const raw = localStorage.getItem(USER_KEY);
      if (!raw) return null;
      const u = JSON.parse(raw);
      if (!u || typeof u !== "object") return null;
      if (typeof u.email !== "string") return null;
      return u as UserSession;
    } catch {
      return null;
    }
  };

  const safeSaveUser = (u: UserSession | null) => {
    try {
      if (!u) localStorage.removeItem(USER_KEY);
      else localStorage.setItem(USER_KEY, JSON.stringify(u));
    } catch {}
  };

  useEffect(() => {
    setSearchRecents(safeLoadRecents());
    const u = safeLoadUser();
    if (u) {
      const next: UserSession = { ...u, lastSeenAt: Date.now() };
      setUser(next);
      safeSaveUser(next);
    }
  }, []);

  const searchIndex: SearchItem[] = useMemo(() => {
    const base: SearchItem[] = topItems.slice(0, 10).map((t) => ({
      id: t.id,
      name: t.name,
      href: t.href,
      img: t.imgBase,
      brand: t.brand,
    }));
    const extra: SearchItem[] = [
      { id: "s1", name: "Exclusivo", href: "/products?tab=exclusivo", img: "/home/files/file-3b.jpg", brand: "JUSP" },
      { id: "s2", name: "Best of all time", href: "/products?tag=top", img: "/home/files/file-2a.jpg", brand: "Multi" },
      { id: "s3", name: "Original brands", href: "/products?tag=original", img: "/home/files/file-2b.jpg", brand: "Original" },
      { id: "s4", name: "Street & minimal", href: "/products?tag=street", img: "/home/files/file-3a.jpg", brand: "Curaduría" },
      { id: "s5", name: "Sport legends", href: "/products?tag=sport", img: "/home/files/file-3c.jpg", brand: "Sport" },
    ];
    return [...base, ...extra];
  }, [topItems]);

  const openSearch = () => {
    setSearchOpen(true);
    setAuthOpen(false);
    requestAnimationFrame(() => inputRef.current?.focus());
  };

  const closeSearch = () => {
    setSearchOpen(false);
    setQ("");
    setSearchResults([]);
    setSearchLoading(false);
  };

  const submitSearch = (text: string) => {
    const s = text.trim();
    if (!s) return;
    safeSaveRecent(s);
    window.location.href = `/products?q=${encodeURIComponent(s)}`;
  };

  useEffect(() => {
    if (!searchOpen) return;
    const trimmed = q.trim();
    const lower = trimmed.toLowerCase();
    if (!trimmed) {
      const quick = [
        ...searchRecents.map((r, i) => ({
          id: `r${i}`,
          name: r,
          href: `/products?q=${encodeURIComponent(r)}`,
          img: "/home/files/file-2a.jpg",
          brand: "Reciente",
        })),
        ...searchIndex.slice(0, 6),
      ].slice(0, 10);
      setSearchResults(quick);
      setSearchLoading(false);
      return;
    }
    const cached = cacheRef.current.get(lower);
    if (cached) {
      setSearchResults(cached);
      setSearchLoading(false);
      lastQueryRef.current = lower;
      return;
    }
    setSearchLoading(true);
    const isRepeatPattern =
      lastQueryRef.current && (lower.startsWith(lastQueryRef.current) || lastQueryRef.current.startsWith(lower));
    const delay = isRepeatPattern ? 0 : 80;
    const t = window.setTimeout(() => {
      const hits = searchIndex
        .map((p) => {
          const name = p.name.toLowerCase();
          const brand = (p.brand ?? "").toLowerCase();
          let score = 0;
          if (name.startsWith(lower)) score += 6;
          if (name.includes(lower)) score += 3;
          if (brand.includes(lower)) score += 2;
          if (user?.email) score += 0.2;
          return { p, score };
        })
        .filter((x) => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 10)
        .map((x) => x.p);
      cacheRef.current.set(lower, hits);
      setSearchResults(hits);
      setSearchLoading(false);
      lastQueryRef.current = lower;
    }, delay);
    return () => window.clearTimeout(t);
  }, [q, searchOpen, searchIndex, searchRecents, user?.email]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "/" && !searchOpen) {
        const t = e.target as HTMLElement | null;
        const isInput = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || (t as any).isContentEditable);
        if (isInput) return;
        e.preventDefault();
        openSearch();
      }
      if (e.key === "Escape") {
        if (searchOpen) closeSearch();
        if (authOpen) setAuthOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [searchOpen, authOpen]);

  const completeLogin = (u: UserSession) => {
    const next: UserSession = { ...u, lastSeenAt: Date.now() };
    setUser(next);
    safeSaveUser(next);
    setAuthOpen(false);
  };

  const handleAuthSubmit = () => {
    const email = authEmail.trim().toLowerCase();
    if (!email || !email.includes("@")) {
      setAuthErr("Escribe un correo válido.");
      return;
    }
    const existing = safeLoadUser();
    if (authMode === "login") {
      const u: UserSession =
        existing?.email === email
          ? { ...existing, lastSeenAt: Date.now() }
          : { email, name: authName.trim() || undefined, createdAt: Date.now(), lastSeenAt: Date.now() };
      completeLogin(u);
      return;
    }
    const u: UserSession = {
      email,
      name: authName.trim() || undefined,
      createdAt: Date.now(),
      lastSeenAt: Date.now(),
      hasPurchased: false,
      onboardingDone: false,
      prefs: { focus: "mix", sizes: [], interests: [] },
    };
    setUser(u);
    safeSaveUser(u);
    setOnboardingStep(1);
    setAuthErr(null);
  };

  const finishOnboarding = () => {
    if (!user) return;
    const next: UserSession = {
      ...user,
      onboardingDone: true,
      prefs: { focus: prefFocus, sizes: prefSizes, interests: prefInterests },
      lastSeenAt: Date.now(),
    };
    setUser(next);
    safeSaveUser(next);
    setAuthOpen(false);
  };

  const topSectionRef = useRef<HTMLElement | null>(null);
  const [topInView, setTopInView] = useState(false);

  useEffect(() => {
    const el = topSectionRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        const en = entries[0];
        const ok = !!en?.isIntersecting && (en.intersectionRatio ?? 0) > 0.12;
        setTopInView(ok);
        if (!ok) setTopPaused(true);
        else setTopPaused(false);
      },
      { root: null, threshold: [0, 0.12, 0.2, 0.4, 0.8] }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const topViewportRef = useRef<HTMLDivElement | null>(null);
  const topCardRefs = useRef<Array<HTMLAnchorElement | null>>([]);
  const [topActive, setTopActive] = useState(0);
  const [topPaused, setTopPaused] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const dragRef = useRef<{
    down: boolean;
    pointerId: number | null;
    startX: number;
    startScrollLeft: number;
  }>({ down: false, pointerId: null, startX: 0, startScrollLeft: 0 });

  const [rubberX, setRubberX] = useState(0);
  const rubberXRef = useRef(0);
  const setRubber = (v: number) => {
    rubberXRef.current = v;
    setRubberX(v);
  };

  const getBounds = () => {
    const vp = topViewportRef.current;
    if (!vp) return { max: 0 };
    const max = Math.max(0, vp.scrollWidth - vp.clientWidth);
    return { max };
  };

  const scrollTopCardHorizontallyToIndex = (idx: number, behavior: ScrollBehavior = "smooth") => {
    const vp = topViewportRef.current;
    const el = topCardRefs.current[idx];
    if (!vp || !el) return;
    const left = el.offsetLeft;
    try {
      vp.scrollTo({ left, behavior });
    } catch {
      vp.scrollLeft = left;
    }
  };

  const snapToNearest = () => {
    const vp = topViewportRef.current;
    if (!vp) return;
    const vpRect = vp.getBoundingClientRect();
    const vpCenter = vpRect.left + vpRect.width / 2;

    let bestIdx = 0;
    let bestD = Number.POSITIVE_INFINITY;

    for (let i = 0; i < topCardRefs.current.length; i++) {
      const el = topCardRefs.current[i];
      if (!el) continue;
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const d = Math.abs(cx - vpCenter);
      if (d < bestD) {
        bestD = d;
        bestIdx = i;
      }
    }

    setTopActive(bestIdx);
    scrollTopCardHorizontallyToIndex(bestIdx, "smooth");
  };

  useEffect(() => {
    if (reduceMotion || topPaused || !topInView) return;
    const intervalMs = isMobile ? 5200 : 3600;
    const t = setInterval(() => {
      setTopActive((i) => (i + 1) % topItems.length);
    }, intervalMs);
    return () => clearInterval(t);
  }, [topPaused, topInView, topItems.length]);

  useEffect(() => {
    if (topPaused || !topInView) return;
    scrollTopCardHorizontallyToIndex(topActive, "smooth");
  }, [topActive, topPaused, topInView]);

  const endDrag = (resume = true) => {
    const vp = topViewportRef.current;
    if (!vp) return;
    dragRef.current.down = false;
    dragRef.current.pointerId = null;
    if (rubberXRef.current !== 0) setRubber(0);
    vp.style.scrollBehavior = "smooth";
    snapToNearest();
    setIsDragging(false);
    if (resume) window.setTimeout(() => setTopPaused(false), isMobile ? 2500 : 1600);
  };

  useEffect(() => {
    if (!isDragging) return;
    const onUp = () => endDrag(true);
    const onCancel = () => endDrag(true);
    window.addEventListener("pointerup", onUp, { passive: true });
    window.addEventListener("pointercancel", onCancel, { passive: true });
    window.addEventListener("blur", onCancel);
    return () => {
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onCancel);
      window.removeEventListener("blur", onCancel);
    };
  }, [isDragging]);

  const onTopPointerDown: React.PointerEventHandler<HTMLDivElement> = (e) => {
    const vp = topViewportRef.current;
    if (!vp) return;
    const isTouchLike = e.pointerType === "touch" || e.pointerType === "pen";
    if (!isTouchLike) return;
    setTopPaused(true);
    setIsDragging(true);
    dragRef.current.down = true;
    dragRef.current.pointerId = e.pointerId;
    dragRef.current.startX = e.clientX;
    dragRef.current.startScrollLeft = vp.scrollLeft;
    vp.style.scrollBehavior = "auto";
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {}
    e.preventDefault();
  };

  const onTopPointerMove: React.PointerEventHandler<HTMLDivElement> = (e) => {
    const vp = topViewportRef.current;
    if (!vp) return;
    if (!dragRef.current.down) return;
    if (dragRef.current.pointerId !== e.pointerId) return;
    const dx = e.clientX - dragRef.current.startX;
    const rawTarget = dragRef.current.startScrollLeft - dx;
    const { max } = getBounds();
    if (rawTarget < 0) {
      setRubber(rawTarget * 0.22);
      vp.scrollLeft = 0;
    } else if (rawTarget > max) {
      setRubber((rawTarget - max) * 0.22);
      vp.scrollLeft = max;
    } else {
      if (rubberXRef.current !== 0) setRubber(0);
      vp.scrollLeft = rawTarget;
    }
  };

  const onTopPointerUp: React.PointerEventHandler<HTMLDivElement> = (e) => {
    if (!dragRef.current.down) return;
    if (dragRef.current.pointerId !== e.pointerId) return;
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
    endDrag(true);
  };

  const onTopPointerCancel: React.PointerEventHandler<HTMLDivElement> = (e) => {
    if (!dragRef.current.down) return;
    if (dragRef.current.pointerId !== e.pointerId) return;
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {}
    endDrag(true);
  };

  const onTopWheel: React.WheelEventHandler<HTMLDivElement> = (e) => {
    const vp = topViewportRef.current;
    if (!vp) return;
    const absX = Math.abs(e.deltaX);
    const absY = Math.abs(e.deltaY);
    if (e.shiftKey || absX > absY) return;
    if (dragRef.current.down) return;
    e.preventDefault();
    window.scrollBy({ top: e.deltaY, left: 0, behavior: "auto" });
  };

  const onTopPointerLeave: React.PointerEventHandler<HTMLDivElement> = () => {
    if (!dragRef.current.down) return;
    endDrag(true);
  };

  /* ==========================================
     BLOQUE 3 · STORIES (VISUAL PRO)
     ========================================== */
  const curatedSlides = useMemo(
    () =>
      Array.from({ length: 15 }, (_, i) => {
        const n = String(i + 1).padStart(2, "0");
        return {
          id: `st${n}`,
          href: "/products?tag=curated",
          imgBase: `/home/stories/story-${n}.jpg`,
          alt: `JUSP Story ${n}`,
          label: `Story ${i + 1}`,
        };
      }),
    []
  );


  const curatedViewportRef = useRef<HTMLDivElement | null>(null);

  const onCuratedWheel: React.WheelEventHandler<HTMLDivElement> = (e) => {
    const vp = curatedViewportRef.current;
    if (!vp) return;
    const absX = Math.abs(e.deltaX);
    const absY = Math.abs(e.deltaY);
    if (e.shiftKey || absX > absY) return;
    e.preventDefault();
    window.scrollBy({ top: e.deltaY, left: 0, behavior: "auto" });
  };

  const storySectionRef = useRef<HTMLElement | null>(null);
  const [storyInView, setStoryInView] = useState(false);

  useEffect(() => {
    const el = storySectionRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        const en = entries[0];
        if (en?.isIntersecting) setStoryInView(true);
      },
      { root: null, threshold: 0.14 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  /* ==========================================
     BLOQUE 4 ·  (3D AUTO)
     ========================================== */
  const collectionCards: CardItem[] = useMemo(
    () => [
            {
        id: "c1",
        kicker: "",
        title: "Converse Chuck Taylor All Star",
        desc: "Esencia: El sneaker más clásico de la historia. Nació como zapato de baloncesto en 1917 y terminó siendo ícono cultural. Minimalista, versátil y atemporal.",
        href: "/products?tag=top",
        img: "/home/mas-top/01",
      },
      {
        id: "c2",
        kicker: "",
        title: "Nike Air Force 1",
        desc: "Esencia: El sneaker urbano más vendido del mundo. Lanzado en 1982, combina simplicidad con presencia fuerte. El modelo blanco es un estándar global.",
        href: "/products?tag=top",
        img: "/home/mas-top/02",
      },
      {
        id: "c3",
        kicker: "",
        title: "Adidas Stan Smith",
        desc: "Esencia: Elegancia minimalista. Diseño limpio, blanco con detalles verdes. Fue el zapato más vendido del mundo en los 80.",
        href: "/products?tag=top",
        img: "/home/mas-top/03",
      },
      {
        id: "c4",
        kicker: "",
        title: "Adidas Superstar",
        desc: "Esencia: Cultura hip-hop y calle. Famoso por su puntera tipo “shell toe”. Se volvió leyenda en los 80 gracias a Run-D.M.C..",
        href: "/products?tag=top",
        img: "/home/mas-top/04",
      },
    ],
    []
  );

    const isCard = (
    c: CardItem
  ): c is Required<Pick<CardItem, "id" | "desc" | "href" | "img">> & { title: string; kicker?: string } => {
    // kicker puede ser vacío; lo importante es que exista el contenido principal
    return Boolean(c && c.id && c.title && c.desc && c.href && c.img);
  };

  const [colActive, setColActive] = useState(0);

  // Cartas válidas
  const colCards = collectionCards.filter(isCard);
  const colLen = Math.max(1, colCards.length);

  // 🔥 Rotación automática NIVEL DIOS (independiente y estable)
  const colLenRef = React.useRef(colLen);
  colLenRef.current = colLen;

  useEffect(() => {
    if (colLenRef.current <= 1) return;

    const interval = setInterval(() => {
      setColActive((prev) => {
        const next = (prev + 1) % colLenRef.current;
        return next;
      });
    }, 3200);

    return () => clearInterval(interval);
  }, []);

  const activeCollection =
    colCards[colActive] ?? colCards[0] ?? collectionCards[0];

  return (
    <main style={{ overflowX: "hidden", background: "#fff", color: "#000" }}>

<style>{`
  :root {
    --jusp-ease: cubic-bezier(.2,.9,.2,1);
  }
  /* Cards */
  .jusp-card {
    transform: translateZ(0);
    transition: transform 280ms var(--jusp-ease), box-shadow 280ms var(--jusp-ease), filter 280ms var(--jusp-ease);
    will-change: transform;
  }
  @media (hover:hover) and (pointer:fine) {
    .jusp-card:hover {
      transform: translateY(-3px) scale(1.008);
      box-shadow: 0 18px 55px rgba(0,0,0,0.14);
    }
  }
  .jusp-card:active {
    transform: translateY(0px) scale(0.988);
  }

  /* Buttons */
  .jusp-btn {
    transition: transform 180ms var(--jusp-ease), filter 180ms var(--jusp-ease), background 180ms var(--jusp-ease);
    will-change: transform;
  }
  @media (hover:hover) and (pointer:fine) {
    .jusp-btn:hover { filter: brightness(1.03); }
  }
  .jusp-btn:active { transform: scale(0.98); }

  /* Save button micro-pop when becomes saved */
  .jusp-save[data-saved="1"] {
    animation: juspPop 260ms var(--jusp-ease);
  }
  @keyframes juspPop {
    0% { transform: scale(0.96); }
    55% { transform: scale(1.06); }
    100% { transform: scale(1.0); }
  }

  /* Focus ring pro */
  .jusp-focus:focus-visible {
    outline: 3px solid rgba(0,0,0,0.20);
    outline-offset: 3px;
  }

  @media (prefers-reduced-motion: reduce) {
    .jusp-card, .jusp-btn { transition: none !important; animation: none !important; }
  }
`}</style>
      {/* ✅ Newsletter modal tipo Nike */}
      {nlOpen ? (
        <div
          role="dialog"
          aria-modal="true"
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 90,
            background: "rgba(0,0,0,0.48)",
            backdropFilter: "blur(10px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 14,
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) closeNewsletter();
          }}
        >
          <div
            style={{
              width: "min(720px, 100%)",
              borderRadius: 22,
              overflow: "hidden",
              background: "#fff",
              border: "1px solid rgba(0,0,0,0.10)",
              boxShadow: "0 28px 110px rgba(0,0,0,0.22)",
            }}
          >
            <div
              style={{
                padding: "14px 14px",
                borderBottom: "1px solid rgba(0,0,0,0.08)",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 12,
              }}
            >
              <div>
                <div style={{ fontSize: 12, fontWeight: 1000, letterSpacing: 1.2, opacity: 0.7 }}>NEWSLETTER</div>
                <div style={{ marginTop: 4, fontSize: 18, fontWeight: 1000 }}>Drops, ofertas y alertas</div>
              </div>
              <button
                type="button"
                onClick={() => closeNewsletter()}
                aria-label="Cerrar"
                style={{
                  height: 40,
                  width: 40,
                  borderRadius: 999,
                  border: "1px solid rgba(0,0,0,0.14)",
                  background: "#fff",
                  cursor: "pointer",
                  fontWeight: 1000,
                }}
              >
                ✕
              </button>
            </div>
            <div style={{ padding: 14 }}>
              <form onSubmit={onNewsletterSubmit} style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <input
                  value={nlEmail}
                  onChange={(e) => setNlEmail(e.target.value)}
                  placeholder="Tu correo"
                  inputMode="email"
                  style={{
                    flex: 1,
                    height: 46,
                    borderRadius: 999,
                    border: "1px solid rgba(0,0,0,0.14)",
                    padding: "0 16px",
                    fontSize: 15,
                    outline: "none",
                  }}
                />
                <button
                  type="submit"
                  disabled={nlStatus === "loading"}
                  style={{
                    height: 46,
                    width: 54,
                    borderRadius: 999,
                    border: "none",
                    background: "#000",
                    color: "#fff",
                    fontWeight: 1000,
                    cursor: "pointer",
                    boxShadow: "0 16px 42px rgba(0,0,0,0.18)",
                    opacity: nlStatus === "loading" ? 0.75 : 1,
                  }}
                >
                  →
                </button>
              </form>
              {nlMsg ? (
                <div style={{ marginTop: 10, fontSize: 13, fontWeight: 900, color: nlStatus === "error" ? "#b00020" : "#0a7a2f" }}>
                  {nlMsg}
                </div>
              ) : (
                <div style={{ marginTop: 10, fontSize: 12, opacity: 0.72, lineHeight: 1.55 }}>
                  Si cierras, no vuelve por 30 días. Si te suscribes, no vuelve a aparecer.
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}

      {/* HERO */}
      <section id="hero" style={{ width: "100vw", minHeight: "calc(100vh - 64px)", position: "relative", background: "#000" }}>
        <video
          ref={videoRef}
          key={videos[videoIndex]}
          muted
          playsInline
          autoPlay
          preload="auto"
          onEnded={onHeroEnded}
          style={{ width: "100%", height: "100%", objectFit: "cover", position: "absolute", inset: 0 }}
        >
          <source src={videos[videoIndex]} type="video/mp4" />
        </video>
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "linear-gradient(180deg, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0.18) 35%, rgba(0,0,0,0.55) 100%)",
          }}
        />
        <div style={{ position: "relative", zIndex: 2, padding: "120px 18px 56px", maxWidth: 1180, margin: "0 auto" }}>
          <div style={{ color: "#fff", opacity: 0.92, fontSize: 12, letterSpacing: 1.6, fontWeight: 800 }}>
            JUSP · ORIGINALES · PREMIUM
          </div>
          <h1 style={{ color: "#fff", margin: "10px 0 0", fontSize: 46, lineHeight: 1.05 }}>JUSP · DO MORE</h1>

          {/* ✅ (QUITADOS) Botón "Ver lo más top" y Botón lupa */}
        </div>
      </section>

      {/* BLOQUE 3 · STORIES (SOLO "HISTORIA" + SIN "VER ") */}
      <section
        ref={(el) => {
          storySectionRef.current = el;
        }}
        style={{
          padding: "22px 0 30px",
          borderTop: "1px solid rgba(0,0,0,0.06)",
          background: "linear-gradient(180deg, rgba(0,0,0,0.02) 0%, rgba(0,0,0,0.00) 100%)",
          opacity: storyInView ? 1 : 0,
          transform: storyInView ? "translateY(0px)" : "translateY(10px)",
          transition: "opacity 680ms cubic-bezier(.2,.9,.2,1), transform 680ms cubic-bezier(.2,.9,.2,1)",
        }}
      >
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "0 14px" }}>
          <div style={{ display: "flex", alignItems: "end", justifyContent: "space-between", gap: 12 }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 1000, letterSpacing: 1.2, opacity: 0.7 }}>HISTORY</div>
              {/* ✅ (QUITADO) "Editorial JUSP · Nivel Dios" */}
            </div>

            {/* ✅ (QUITADO) "Ver colección →" */}
          </div>

          <div
            ref={curatedViewportRef}
            onWheel={onCuratedWheel}
            style={{
              marginTop: 14,
              overflowX: "auto",
              scrollSnapType: "x mandatory",
              WebkitOverflowScrolling: "touch",
              overscrollBehaviorX: "contain",
              scrollbarWidth: "none",
              padding: "8px 2px 10px",
            }}
          >
            <div style={{ display: "flex", gap: 12, alignItems: "stretch" }}>
              {curatedSlides.map((s, idx) => (
                <Link
                  key={s.id}
                  href={s.href}
                  aria-label={s.alt}
                  style={{
                    flex: "0 0 auto",
                    scrollSnapAlign: "start",
                    textDecoration: "none",
                    color: "#000",
                  }}
                >
                  <div
                    style={{
                      width: "min(64vw, 260px)",
                      aspectRatio: "9 / 16",
                      borderRadius: 22,
                      overflow: "hidden",
                      border: "1px solid rgba(0,0,0,0.10)",
                      background: "#f2f2f2",
                      boxShadow: "0 18px 55px rgba(0,0,0,0.14)",
                      transform: "translateZ(0)",
                      position: "relative",
                    }}
                  >
                    <SmartImg
                      baseSrc={s.imgBase}
                      alt={s.alt}
                      loading={idx < 2 ? "eager" : "lazy"}
                      fetchPriority={idx < 2 ? "high" : "low"}
                      style={{
                        width: "100%",
                        height: "100%",
                        objectFit: "cover",
                        userSelect: "none",
                        pointerEvents: "none",
                      }}
                    />
<div
                      style={{
                        position: "absolute",
                        inset: 0,
                        background:
                          "linear-gradient(180deg, rgba(0,0,0,0.08) 0%, rgba(0,0,0,0.0) 40%, rgba(0,0,0,0.30) 100%)",
                        pointerEvents: "none",
                      }}
                    />
                    <div
                      style={{
                        position: "absolute",
                        left: 10,
                        top: 10,
                        padding: "6px 10px",
                        borderRadius: 999,
                        background: "rgba(0,0,0,0.50)",
                        color: "#fff",
                        fontSize: 11,
                        fontWeight: 1000,
                        letterSpacing: 0.6,
                        border: "1px solid rgba(255,255,255,0.18)",
                        backdropFilter: "blur(10px)",
                      }}
                    >
                      JUSP
                    </div>
                  </div>
                </Link>
              ))}
              <div style={{ flex: "0 0 6px" }} />
            </div>
          </div>
        </div>
      </section>

      {/* BLOQUE 2.5 · CONFIANZA JUSP */}
      <section
        style={{
          padding: "10px 0 26px",
          borderTop: "1px solid rgba(0,0,0,0.06)",
          background: "linear-gradient(180deg, rgba(0,0,0,0.00) 0%, rgba(0,0,0,0.02) 100%)",
        }}
      >
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "0 14px" }}>
          <div style={{ display: "flex", alignItems: "end", justifyContent: "space-between", gap: 12 }}>
            <div>
              <div style={{ fontSize: 12, fontWeight: 1000, letterSpacing: 1.2, opacity: 0.7 }}>CONFIANZA</div>
              <div style={{ fontSize: 22, fontWeight: 1000, marginTop: 6 }}>Originales ➡️ Directo ➡️ Flash</div>
              <div style={{ marginTop: 6, fontSize: 13, opacity: 0.75 }}>
                Transparencia total: compra internacional + entrega a Colombia, con acompañamiento real.
              </div>
            </div>
            <Link href="/terms" style={{ fontSize: 13, fontWeight: 900, textDecoration: "none", color: "#000", opacity: 0.85 }}>
              Ver términos →
            </Link>
          </div>

          <div
            style={{
              marginTop: 14,
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
              gap: 14,
            }}
          >
            {[
              { k: "auth", t: "Originales verificados", d: "Proveedores seleccionados + control de calidad.", i: "✅" },
              { k: "ship", t: "Envío internacional claro", d: "Costo y tiempos transparentes. Sin sorpresas.", i: "✈️" },
              { k: "care", t: "Soporte humano", d: "Te acompañamos antes y después de comprar.", i: "💬" },
            ].map((b) => (
              <div
                key={b.k}
                style={{
                  border: "1px solid rgba(0,0,0,0.08)",
                  borderRadius: 20,
                  padding: 16,
                  background: "#fff",
                  boxShadow: "0 14px 50px rgba(0,0,0,0.08)",
                }}
              >
                <div style={{ fontSize: 22 }}>{b.i}</div>
                <div style={{ marginTop: 10, fontWeight: 1000, fontSize: 15 }}>{b.t}</div>
                <div style={{ marginTop: 6, fontSize: 13, opacity: 0.75, lineHeight: 1.4 }}>{b.d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>


{/* BLOQUE 2 */}
      <section
        id="top-picks"
        ref={(el) => {
          topSectionRef.current = el;
        }}
        style={{ padding: "26px 0 10px", borderTop: "1px solid rgba(0,0,0,0.06)" }}
      >
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "0 14px" }}>
            <div className="tpWrap">
              <div className="tpHeader">
                <div>
                  <div className="tpKicker">LO MÁS TOP</div>
                  <h2 className="tpTitle">
                  </h2>
                </div>

                <Link className="tpAll" href="/search?tab=top">
                  Ver todo →
                </Link>
              </div>

              <div className="tpControls">
                <form
                  className="tpSearch"
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (topQuery.trim()) window.location.href = `/search?q=${encodeURIComponent(topQuery.trim())}`;
                  }}
                >
                  <span aria-hidden style={{ opacity: 0.65, fontSize: 14 }}>🔎</span>
                  <input
                    value={topQuery}
                    onChange={(e) => setTopQuery(e.target.value)}
                    placeholder="Buscar (ej: Air Force, hoodie...)"
                    style={{
                      border: "none",
                      outline: "none",
                      flex: 1,
                      minWidth: 0,
                      fontSize: 14,
                      background: "transparent",
                    }}
                  />
                  <button
                    type="submit"
                    className="jusp-btn jusp-focus"
                    style={{
                      border: "none",
                      background: "#0b0b0b",
                      color: "#fff",
                      borderRadius: 999,
                      padding: "10px 14px",
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    Buscar
                  </button>
                </form>

                <div className="tpChips">
                  {TOP_CHIPS.map((c) => (
                    <button
                      key={c}
                      className="jusp-btn jusp-focus"
                      onClick={() => {
                        setTopQuery(c);
                        window.location.href = `/search?q=${encodeURIComponent(c)}`;
                      }}
                      style={{
                        border: "1px solid #e7e7e7",
                        background: "#f7f7f7",
                        borderRadius: 999,
                        padding: "10px 14px",
                        fontWeight: 700,
                        cursor: "pointer",
                      }}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <style>{`
                .tpWrap {
                  margin-top: 22px;
                }
                .tpHeader {
                  display: flex;
                  align-items: flex-end;
                  justify-content: space-between;
                  gap: 16px;
                  flex-wrap: wrap;
                }
                .tpKicker {
                  font-size: 12px;
                  letter-spacing: 0.14em;
                  text-transform: uppercase;
                  opacity: 0.7;
                  font-weight: 800;
                }
                .tpTitle {
                  margin: 6px 0 0;
                  font-size: 44px;
                  line-height: 1;
                  font-weight: 900;
                }
                .tpCount {
                  font-weight: 900;
                  opacity: 0.9;
                }
                .tpSubtitle {
                  margin: 10px 0 0;
                  opacity: 0.75;
                  max-width: 560px;
                }
                .tpAll {
                  font-weight: 800;
                  color: #111;
                  text-decoration: none;
                  display: inline-flex;
                  gap: 8px;
                  align-items: center;
                  padding: 8px 10px;
                  border-radius: 999px;
                  background: rgba(0,0,0,0.04);
                }
                .tpControls {
                  margin-top: 14px;
                  display: flex;
                  align-items: center;
                  justify-content: space-between;
                  gap: 10px;
                  flex-wrap: wrap;
                }
                .tpSearch {
                  flex: 1 1 380px;
                  display: flex;
                  align-items: center;
                  gap: 10px;
                  padding: 10px 12px;
                  border: 1px solid #e6e6e6;
                  border-radius: 999px;
                  background: #fff;
                  box-shadow: 0 10px 24px rgba(0,0,0,0.06);
                }
                .tpChips {
                  display: flex;
                  gap: 10px;
                  align-items: center;
                  flex-wrap: wrap;
                }

                @media (max-width: 720px) {
                  .tpTitle { font-size: 34px; }
                  .tpSubtitle { max-width: 100%; }
                  .tpControls {
                    flex-direction: column;
                    align-items: stretch;
                  }
                  .tpSearch {
                    flex: 1 1 auto;
                    width: 100%;
                  }
                  .tpChips {
                    flex-wrap: nowrap;
                    overflow-x: auto;
                    padding-bottom: 6px;
                    -webkit-overflow-scrolling: touch;
                  }
                  .tpChips::-webkit-scrollbar { display: none; }
                }
              `}</style>
            </div>
        </div>

        <div style={{ marginTop: 16, position: "relative" }}>
          <div
            ref={topViewportRef}
            onMouseEnter={() => setTopPaused(true)}
            onMouseLeave={() => setTopPaused(false)}
            onWheel={onTopWheel}
            onPointerDown={onTopPointerDown}
            onPointerMove={onTopPointerMove}
            onPointerUp={onTopPointerUp}
            onPointerCancel={onTopPointerCancel}
            onPointerLeave={onTopPointerLeave}
            style={{
              overflowX: "auto",
              scrollSnapType: "x mandatory",
              WebkitOverflowScrolling: "touch",
              scrollbarWidth: "none",
              overscrollBehaviorX: "contain",
              padding: "10px 14px 18px",
              touchAction: isDragging ? "none" : "pan-y",
              userSelect: isDragging ? "none" : "auto",
              cursor: isDragging ? "grabbing" : "auto",
            }}
          >
            <div
              style={{
                display: "flex",
                gap: 0,
                transform: rubberX ? `translateX(${rubberX}px)` : "translateX(0px)",
                transition: rubberX ? "none" : "transform 220ms cubic-bezier(.2,.9,.2,1)",
                willChange: "transform",
              }}
            >
              {topItems.slice(0, 10).map((it, idx) => {
                const isActive = idx === topActive;
                return (
                  <Link
                    key={(it?.href ? it.href : String(idx))}
                    className="jusp-card"
                    href={it.href}
                    ref={(el) => {
                      topCardRefs.current[idx] = el;
                    }}
                    onMouseEnter={() => setTopActive(idx)}
                    style={{
                      scrollSnapAlign: "start",
                      textDecoration: "none",
                      color: "#000",
                      flex: "0 0 calc(100vw - 28px)",
                      width: "calc(100vw - 28px)",
                      maxWidth: "calc(100vw - 28px)",
                      borderRadius: 26, marginTop: isMobile ? 10 : 0,
                      position: "relative",
                      overflow: "hidden",
                      border: "1px solid rgba(0,0,0,0.08)",
                      boxShadow: isActive ? "0 22px 80px rgba(0,0,0,0.18)" : "0 10px 30px rgba(0,0,0,0.10)",
                      transform: isActive
                        ? "perspective(1200px) translateZ(0) scale(1.01)"
                        : "perspective(1200px) translateZ(0) scale(0.985)",
                      transition: "transform 420ms cubic-bezier(.2,.9,.2,1), box-shadow 420ms cubic-bezier(.2,.9,.2,1)",
                      background: "#fff",
                    }}
                  >
                    <div style={{ height: "min(66vh, 520px)", minHeight: 360, background: "#f6f6f6", position: "relative" }}>
                      <TopPickMedia
                        baseSrc={it.imgBase}
                        alt={it.name}
                        active={isActive}
                      />
                      <div
                        style={{
                          position: "absolute",
                          inset: 0,
                          background: "radial-gradient(1200px 520px at 50% 55%, rgba(0,0,0,0.0) 35%, rgba(0,0,0,0.38) 100%)",
                          pointerEvents: "none",
                          opacity: isActive ? 1 : 0.72,
                          transition: "opacity 420ms ease",
                        }}
                      />
                      <div style={{ position: "absolute", left: 0, bottom: 0, height: 3, width: "100%", background: "rgba(255,255,255,0.16)" }}>
                        <div
                          style={{
                            height: "100%",
                            width: isActive ? "100%" : "0%",
                            background: "#fff",
                            opacity: 0.92,
                            transition: isActive ? "width 2600ms linear" : "width 220ms ease",
                          }}
                        />
                      </div>

                    <div
                      style={{
                        position: "absolute",
                        left: 16,
                        right: 16,
                        bottom: 14,
                        display: "flex",
                        alignItems: "end",
                        justifyContent: "space-between",
                        gap: 12,
                        padding: "14px 14px",
                        borderRadius: 18,
                        background: "linear-gradient(180deg, rgba(0,0,0,0.05) 0%, rgba(0,0,0,0.55) 100%)",
                        color: "#fff",
                        backdropFilter: "blur(8px)",
                        border: "1px solid rgba(255,255,255,0.14)",
                      }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 11, fontWeight: 900, letterSpacing: 1.2, opacity: 0.9 }}>
                          {(it.brand || "JUSP").toUpperCase()} · ORIGINALES
                        </div>
                        <div
                          style={{
                            marginTop: 6,
                            fontSize: 18,
                            fontWeight: 1000,
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                        >
                          {it.name}
                        </div>
                        <div style={{ marginTop: 6, fontSize: 12, opacity: 0.85 }}>
                          {it.price || "Drop Top"} · Envío internacional transparente
                        </div>
                      </div>

                      <div style={{ display: "flex", alignItems: "center", gap: 10, flex: "0 0 auto" }}>
                        <SaveTopButton
                          id={it.id}
                          saved={savedTopIds.includes(it.id)}
                          onToggle={(id) => {
                            const next = savedTopIds.includes(id)
                              ? savedTopIds.filter((x) => x !== id)
                              : [...savedTopIds, id];
                            setSavedTopIds(next);
                          }}
                        />
                        <span
                          style={{
                            display: "inline-flex",
                            alignItems: "center",
                            justifyContent: "center",
                            width: 36,
                            height: 36,
                            borderRadius: 999,
                            background: "rgba(255,255,255,0.90)",
                            color: "#000",
                            fontWeight: 1000,
                          }}
                          aria-hidden="true"
                        >
                          →
                        </span>
                      </div>
                    </div>

                    </div>
                  </Link>
                );
              })}
            </div>
          </div>

          <div style={{ maxWidth: 1180, margin: "0 auto", padding: "0 14px", fontSize: 12, opacity: 0.7 }}>
            Desliza horizontalmente para ver más.
          </div>
        </div>
      </section>

      
      {/* BLOQUE 5 · TODOS LOS PRODUCTOS */}
<section style={{ padding: "26px 0 44px", borderTop: "1px solid rgba(0,0,0,0.06)" }}>
  <div style={{ maxWidth: 1180, margin: "0 auto", padding: "0 14px" }}>
    <div style={{ display: "flex", alignItems: "end", justifyContent: "space-between", gap: 12 }}>
      <div>
        <div style={{ fontSize: 12, fontWeight: 1000, letterSpacing: 1.2, opacity: 0.7 }}>TODOS</div>
        <div style={{ fontSize: 28, fontWeight: 1000, marginTop: 8 }}>Todos los productos</div>
        <div style={{ marginTop: 6, fontSize: 13, opacity: 0.75 }}>
          Grid tipo marketplace: rápido de escanear, directo al producto.
        </div>
      </div>
    </div>

    {/* Tabs */}
    <div style={{ marginTop: 14, display: "flex", gap: 10, flexWrap: "wrap" }}>
      {["Te podría gustar", "Deportes", "Moda", "Accesorios", "Niños"].map((t) => (
        <button
          key={t}
          onClick={() => setTopQuery(t === "Te podría gustar" ? "" : t)}
          style={{
            padding: "10px 12px",
            borderRadius: 999,
            border: "1px solid rgba(0,0,0,0.10)",
            background: (topQuery || "") === (t === "Te podría gustar" ? "" : t) ? "rgba(0,0,0,0.92)" : "white",
            color: (topQuery || "") === (t === "Te podría gustar" ? "" : t) ? "white" : "rgba(0,0,0,0.85)",
            fontWeight: 900,
            fontSize: 12,
            letterSpacing: 0.2,
            cursor: "pointer",
          }}
        >
          {t}
        </button>
      ))}
    </div>

    {/* Grid */}
    <div
      style={{
        marginTop: 16,
        display: "grid",
        gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
        gap: 14,
      }}
    >
      {ALL_PRODUCTS.filter((p) => {
        const q = (topQuery || "").trim().toLowerCase();
        if (!q) return true;
        return (p.name + " " + (p.brand ?? "")).toLowerCase().includes(q);
      }).map((p) => (
        <a
          key={p.id}
          href={p.href}
          style={{
            display: "block",
            textDecoration: "none",
            color: "inherit",
            borderRadius: 18,
            border: "1px solid rgba(0,0,0,0.08)",
            background: "white",
            overflow: "hidden",
            boxShadow: "0 10px 30px rgba(0,0,0,0.06)",
          }}
        >
          <div style={{ position: "relative", background: "#f7f7f7" }}>
            <div style={{ height: 220, position: "relative" }}>
              <SmartImg
                baseSrc={p.imgBase}
                alt={p.name}
                style={{ width: "100%", height: "100%", objectFit: "contain", display: "block" }}
              />
            </div>

            <div
              style={{
                position: "absolute",
                left: 10,
                top: 10,
                padding: "8px 10px",
                borderRadius: 999,
                background: "rgba(255,255,255,0.92)",
                border: "1px solid rgba(0,0,0,0.08)",
                fontSize: 12,
                fontWeight: 1000,
              }}
            >
              {p.brand ?? "JUSP"}
            </div>
          </div>

          <div style={{ padding: 12 }}>
            <div style={{ fontWeight: 1000, fontSize: 14, lineHeight: 1.2 }}>{p.name}</div>
            <div style={{ marginTop: 6, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
              <div style={{ fontSize: 12, opacity: 0.72 }}>{p.price ?? "Oferta"}</div>
              <div
                style={{
                  fontSize: 12,
                  fontWeight: 1000,
                  padding: "8px 10px",
                  borderRadius: 999,
                  background: "rgba(0,0,0,0.92)",
                  color: "white",
                }}
              >
                Ver →
              </div>
            </div>
          </div>
        </a>
      ))}
    </div>

    {/* Responsive: 4 columnas desktop */}
    <style>{`
      @media (min-width: 880px) {
        .__jusp_all_products_grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
      }
    `}</style>
  </div>
</section>


      {/* SEARCH OVERLAY (queda disponible por tecla "/" aunque quitamos botones del hero) */}
      {searchOpen ? (
        <div
          role="dialog"
          aria-modal="true"
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 80,
            background: "rgba(0,0,0,0.44)",
            backdropFilter: "blur(10px)",
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) closeSearch();
          }}
        >
          <div style={{ position: "absolute", inset: 0, background: "#fff", overflow: "auto" }}>
            <div
              style={{
                position: "sticky",
                top: 0,
                zIndex: 2,
                padding: "18px 14px 12px",
                borderBottom: "1px solid rgba(0,0,0,0.08)",
                background: "rgba(255,255,255,0.92)",
                backdropFilter: "blur(10px)",
              }}
            >
              <div style={{ maxWidth: 1180, margin: "0 auto", display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ fontWeight: 1000, letterSpacing: 1.4, fontSize: 12, opacity: 0.75 }}>JUSP</div>
                <div style={{ flex: 1, display: "flex", gap: 8, alignItems: "center" }}>
                  <input
                    ref={inputRef}
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder="Buscar productos, marcas, estilos…"
                    aria-label="Buscar"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") submitSearch(q);
                    }}
                    style={{
                      width: "100%",
                      height: 46,
                      borderRadius: 999,
                      border: "1px solid rgba(0,0,0,0.14)",
                      padding: "0 16px",
                      fontSize: 15,
                      outline: "none",
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => submitSearch(q)}
                    aria-label="Buscar"
                    title="Buscar"
                    style={{
                      height: 46,
                      width: 56,
                      borderRadius: 999,
                      border: "none",
                      background: "#000",
                      color: "#fff",
                      fontWeight: 1000,
                      cursor: "pointer",
                      boxShadow: "0 16px 42px rgba(0,0,0,0.18)",
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 18,
                      lineHeight: 1,
                    }}
                  >
                    🔍
                  </button>
                </div>
                <button
                  type="button"
                  onClick={closeSearch}
                  aria-label="Cerrar"
                  style={{
                    height: 46,
                    width: 46,
                    borderRadius: 999,
                    border: "1px solid rgba(0,0,0,0.14)",
                    background: "#fff",
                    cursor: "pointer",
                    fontWeight: 1000,
                  }}
                >
                  ✕
                </button>
              </div>
            </div>

            <div style={{ maxWidth: 1180, margin: "0 auto", padding: "14px 14px 30px" }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 1000, opacity: 0.72 }}>
                  {q.trim() ? "Resultados" : searchRecents.length ? "Recientes" : "Sugerencias"}
                </div>
                <div style={{ fontSize: 12, opacity: 0.65 }}>
                  Tip: <span style={{ fontWeight: 1000 }}>ESC</span> para cerrar
                </div>
              </div>

              {searchLoading ? <div style={{ marginTop: 16, fontSize: 13, opacity: 0.7 }}>Buscando…</div> : null}

              <div
                style={{
                  marginTop: 14,
                  display: "grid",
                  gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
                  gap: 12,
                }}
              >
                {searchResults.map((p) => (
                  <Link
                    key={p.id + p.href}
                    href={p.href}
                    onClick={() => {
                      if (q.trim()) safeSaveRecent(q.trim());
                      setSearchOpen(false);
                    }}
                    style={{
                      textDecoration: "none",
                      color: "#000",
                      borderRadius: 18,
                      overflow: "hidden",
                      border: "1px solid rgba(0,0,0,0.08)",
                      boxShadow: "0 12px 30px rgba(0,0,0,0.08)",
                      background: "#fff",
                      transform: "translateZ(0)",
                      transition: "transform 220ms ease, box-shadow 220ms ease",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = "translateY(-2px) scale(1.01)";
                      e.currentTarget.style.boxShadow = "0 20px 48px rgba(0,0,0,0.12)";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = "translateY(0px) scale(1)";
                      e.currentTarget.style.boxShadow = "0 12px 30px rgba(0,0,0,0.08)";
                    }}
                  >
                    <div style={{ position: "relative", height: 220, background: "#f4f4f4" }}>
                      <SmartImg baseSrc={p.img} alt={p.name} loading="lazy" fetchPriority="auto" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(0,0,0,0.0) 55%, rgba(0,0,0,0.44) 100%)" }} />
                      <div style={{ position: "absolute", left: 12, right: 12, bottom: 10, color: "#fff" }}>
                        <div style={{ fontSize: 12, fontWeight: 1000, opacity: 0.9 }}>{p.brand ?? "Original"}</div>
                        <div style={{ marginTop: 4, fontSize: 16, fontWeight: 1000, lineHeight: 1.1 }}>{p.name}</div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              {!q.trim() && searchRecents.length ? (
                <button
                  type="button"
                  onClick={() => {
                    try {
                      localStorage.removeItem(SEARCH_RECENTS_KEY);
                    } catch {}
                    setSearchRecents([]);
                  }}
                  style={{
                    marginTop: 16,
                    border: "none",
                    background: "transparent",
                    cursor: "pointer",
                    fontSize: 13,
                    opacity: 0.7,
                    textDecoration: "underline",
                  }}
                >
                  Borrar recientes
                </button>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

      {/* AUTH MODAL */}
      {authOpen ? (
        <div
          role="dialog"
          aria-modal="true"
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 85,
            background: "rgba(0,0,0,0.48)",
            backdropFilter: "blur(10px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 14,
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setAuthOpen(false);
          }}
        >
          <div
            style={{
              width: "min(680px, 100%)",
              borderRadius: 22,
              overflow: "hidden",
              background: "#fff",
              border: "1px solid rgba(0,0,0,0.10)",
              boxShadow: "0 28px 110px rgba(0,0,0,0.22)",
            }}
          >
            <div
              style={{
                padding: "14px 14px",
                borderBottom: "1px solid rgba(0,0,0,0.08)",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 12,
              }}
            >
              <div>
                <div style={{ fontSize: 12, fontWeight: 1000, letterSpacing: 1.2, opacity: 0.7 }}>CUENTA</div>
                <div style={{ marginTop: 4, fontSize: 18, fontWeight: 1000 }}>
                  {authMode === "login" ? "Iniciar sesión" : "Crear cuenta"}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setAuthOpen(false)}
                aria-label="Cerrar"
                style={{
                  height: 40,
                  width: 40,
                  borderRadius: 999,
                  border: "1px solid rgba(0,0,0,0.14)",
                  background: "#fff",
                  cursor: "pointer",
                  fontWeight: 1000,
                }}
              >
                ✕
              </button>
            </div>

            <div style={{ padding: 14 }}>
              {onboardingStep === 0 ? (
                <>
                  <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
                    <button
                      type="button"
                      onClick={() => setAuthMode("login")}
                      style={{
                        flex: 1,
                        height: 42,
                        borderRadius: 999,
                        border: "1px solid rgba(0,0,0,0.14)",
                        background: authMode === "login" ? "#000" : "#fff",
                        color: authMode === "login" ? "#fff" : "#000",
                        fontWeight: 1000,
                        cursor: "pointer",
                        transition: "transform 180ms ease",
                      }}
                    >
                      Iniciar sesión
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthMode("signup")}
                      style={{
                        flex: 1,
                        height: 42,
                        borderRadius: 999,
                        border: "1px solid rgba(0,0,0,0.14)",
                        background: authMode === "signup" ? "#000" : "#fff",
                        color: authMode === "signup" ? "#fff" : "#000",
                        fontWeight: 1000,
                        cursor: "pointer",
                      }}
                    >
                      Registrarme
                    </button>
                  </div>

                  <div style={{ display: "grid", gap: 10 }}>
                    {authMode === "signup" ? (
                      <input
                        value={authName}
                        onChange={(e) => setAuthName(e.target.value)}
                        placeholder="Nombre (opcional)"
                        style={{
                          height: 46,
                          borderRadius: 14,
                          border: "1px solid rgba(0,0,0,0.14)",
                          padding: "0 12px",
                          outline: "none",
                        }}
                      />
                    ) : null}

                    <input
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      placeholder="Correo"
                      inputMode="email"
                      style={{
                        height: 46,
                        borderRadius: 14,
                        border: "1px solid rgba(0,0,0,0.14)",
                        padding: "0 12px",
                        outline: "none",
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleAuthSubmit();
                      }}
                    />
                    {authErr ? <div style={{ fontSize: 13, color: "#b00020", fontWeight: 900 }}>{authErr}</div> : null}
                    <button
                      type="button"
                      onClick={handleAuthSubmit}
                      style={{
                        height: 46,
                        borderRadius: 999,
                        border: "none",
                        background: "#000",
                        color: "#fff",
                        fontWeight: 1000,
                        cursor: "pointer",
                        boxShadow: "0 16px 42px rgba(0,0,0,0.18)",
                      }}
                    >
                      {authMode === "login" ? "Entrar" : "Continuar"}
                    </button>
                    <div style={{ marginTop: 6, fontSize: 12, opacity: 0.7, lineHeight: 1.55 }}>
                      * Versión PRO MAX (sin backend): guardamos tu sesión en el navegador por ahora.
                    </div>
                  </div>
                </>
              ) : null}

              {onboardingStep === 1 ? (
                <>
                  <div style={{ fontSize: 13, fontWeight: 1000, opacity: 0.78 }}>Onboarding premium</div>
                  <div style={{ marginTop: 8, fontSize: 20, fontWeight: 1000, letterSpacing: -0.2 }}>¿Qué te interesa más?</div>
                  <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 10 }}>
                    {[
                      { k: "hombre" as const, t: "Hombre" },
                      { k: "mujer" as const, t: "Mujer" },
                      { k: "ninos" as const, t: "Niños" },
                      { k: "mix" as const, t: "Mix" },
                    ].map((x) => (
                      <button
                        key={x.k}
                        type="button"
                        onClick={() => setPrefFocus(x.k)}
                        style={{
                          height: 44,
                          borderRadius: 14,
                          border: "1px solid rgba(0,0,0,0.14)",
                          background: prefFocus === x.k ? "#000" : "#fff",
                          color: prefFocus === x.k ? "#fff" : "#000",
                          fontWeight: 1000,
                          cursor: "pointer",
                        }}
                      >
                        {x.t}
                      </button>
                    ))}
                  </div>

                  <div style={{ marginTop: 14, fontSize: 13, fontWeight: 1000, opacity: 0.78 }}>Tallas rápidas</div>
                  <div style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {["38", "39", "40", "41", "42", "43", "S", "M", "L", "XL"].map((s) => {
                      const on = prefSizes.includes(s);
                      return (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setPrefSizes((p) => (on ? p.filter((x) => x !== s) : [...p, s]))}
                          style={{
                            height: 36,
                            padding: "0 12px",
                            borderRadius: 999,
                            border: "1px solid rgba(0,0,0,0.14)",
                            background: on ? "#000" : "#fff",
                            color: on ? "#fff" : "#000",
                            fontWeight: 1000,
                            cursor: "pointer",
                            fontSize: 13,
                          }}
                        >
                          {s}
                        </button>
                      );
                    })}
                  </div>

                  <div style={{ marginTop: 14, display: "flex", gap: 10, justifyContent: "flex-end" }}>
                    <button
                      type="button"
                      onClick={() => setOnboardingStep(2)}
                      style={{
                        height: 44,
                        padding: "0 16px",
                        borderRadius: 999,
                        border: "none",
                        background: "#000",
                        color: "#fff",
                        fontWeight: 1000,
                        cursor: "pointer",
                      }}
                    >
                      Continuar →
                    </button>
                  </div>
                </>
              ) : null}

              {onboardingStep === 2 ? (
                <>
                  <div style={{ fontSize: 13, fontWeight: 1000, opacity: 0.78 }}>Último toque</div>
                  <div style={{ marginTop: 8, fontSize: 20, fontWeight: 1000, letterSpacing: -0.2 }}>¿Qué estilo quieres ver primero?</div>
                  <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {["Minimal", "Street", "Premium", "Running", "Gym", "Outdoor"].map((s) => {
                      const on = prefInterests.includes(s);
                      return (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setPrefInterests((p) => (on ? p.filter((x) => x !== s) : [...p, s]))}
                          style={{
                            height: 38,
                            padding: "0 14px",
                            borderRadius: 999,
                            border: "1px solid rgba(0,0,0,0.14)",
                            background: on ? "#000" : "#fff",
                            color: on ? "#fff" : "#000",
                            fontWeight: 1000,
                            cursor: "pointer",
                            fontSize: 13,
                          }}
                        >
                          {s}
                        </button>
                      );
                    })}
                  </div>

                  <div style={{ marginTop: 14, display: "flex", gap: 10, justifyContent: "space-between", alignItems: "center" }}>
                    <button
                      type="button"
                      onClick={() => setOnboardingStep(1)}
                      style={{
                        height: 44,
                        padding: "0 14px",
                        borderRadius: 999,
                        border: "1px solid rgba(0,0,0,0.14)",
                        background: "#fff",
                        cursor: "pointer",
                        fontWeight: 1000,
                      }}
                    >
                      ← Atrás
                    </button>
                    <button
                      type="button"
                      onClick={finishOnboarding}
                      style={{
                        height: 44,
                        padding: "0 16px",
                        borderRadius: 999,
                        border: "none",
                        background: "#000",
                        color: "#fff",
                        fontWeight: 1000,
                        cursor: "pointer",
                        boxShadow: "0 16px 42px rgba(0,0,0,0.18)",
                      }}
                    >
                      Terminar
                    </button>
                  </div>

                  <div style={{ marginTop: 10, fontSize: 12, opacity: 0.72, lineHeight: 1.55 }}>
                    Micro-UX: no cambiamos diseño, solo prioridad/timing según contexto (primera visita vs recurrente vs logueado).
                  </div>
                </>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}
    
      {/* FOOTER · NIKE-LIKE MINIMAL */}
      

{/* (footer removed) */}



</main>
  );
}