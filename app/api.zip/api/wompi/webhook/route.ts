import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { dbGetOrderByCode, dbInsertLog, dbUpsertOrder } from "@/lib/ordersRepo";
import {
  consumeExcelReservationAndDecrement,
  decrementExcelStock,
  releaseExcelReservation,
} from "@/lib/stockExcel";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type WompiTransaction = {
  id?: string;
  status?: string;
  reference?: string;
  amount_in_cents?: number;
  currency?: string;
  customer_email?: string | null;
  shipping_address?: {
    address_line_1?: string | null;
    city?: string | null;
    region?: string | null;
    country?: string | null;
    phone_number?: string | null;
    name?: string | null;
  } | null;
};

function getSupabaseAdmin() {
  const url =
    process.env.NEXT_PUBLIC_SUPABASE_URL ||
    process.env.SUPABASE_URL ||
    "";
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || "";

  if (!url || !key) {
    throw new Error("Missing Supabase env vars");
  }

  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

async function syncDashboardPaymentData(params: {
  reference: string;
  transactionId: string;
  eventName: string;
  wompiStatus: string;
  tx: WompiTransaction;
  orderId: string | null;
}) {
  const { reference, transactionId, eventName, wompiStatus, tx, orderId } = params;
  const supabase = getSupabaseAdmin();
  const amountInCents = Number(tx.amount_in_cents || 0);
  const amountCop = Math.round(amountInCents / 100);
  const normalizedStatus = wompiStatus.toLowerCase();
  const eventAt = new Date().toISOString();

  const paymentPayload = {
    order_id: orderId,
    provider: "wompi",
    amount_cop: amountCop,
    currency: tx.currency || "COP",
    status: normalizedStatus,
    provider_ref: transactionId,
  };

  const { data: existingPayment } = await supabase
    .from("payments")
    .select("id")
    .eq("provider_ref", transactionId)
    .maybeSingle();

  if (existingPayment?.id) {
    await supabase.from("payments").update(paymentPayload).eq("id", existingPayment.id);
  } else {
    await supabase.from("payments").insert(paymentPayload);
  }

  await supabase.from("payment_events").insert({
    provider: "wompi",
    provider_event_id: `${eventName || "transaction.updated"}:${transactionId}:${wompiStatus}`,
    event_type: eventName || "transaction.updated",
    transaction_id: transactionId,
    reference,
    status: normalizedStatus,
    amount_in_cents: amountInCents,
    currency: tx.currency || "COP",
    event_at: eventAt,
    created_at: eventAt,
  });
}

function getTransactionId(body: any): string {
  return String(
    body?.data?.transaction?.id ||
      body?.data?.id ||
      body?.transaction?.id ||
      body?.id ||
      ""
  ).trim();
}

function getEventName(body: any): string {
  return String(body?.event || body?.type || "").trim();
}

function mapWompiStatus(statusRaw: string | undefined | null) {
  const status = String(statusRaw || "").toUpperCase();

  if (status === "APPROVED") return "paid";
  if (status === "PENDING") return "pending";
  if (status === "DECLINED") return "cancelled";
  if (status === "VOIDED") return "cancelled";
  if (status === "ERROR") return "cancelled";

  return "pending";
}

function toSafeQty(value: unknown): number {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.floor(n);
}

function sanitizeOrderItems(items: any[]) {
  return items
    .map((item) => ({
      id: String(item?.id || item?.product_id || "").trim(),
      product_id: String(item?.product_id || item?.id || "").trim() || null,
      size: item?.size ? String(item.size).trim() : null,
      color: item?.color ? String(item.color).trim() : null,
      qty: toSafeQty(item?.qty),
    }))
    .filter((item) => item.id && item.qty > 0);
}

async function fetchTransactionFromWompi(transactionId: string): Promise<WompiTransaction> {
  const privateKey = (process.env.WOMPI_PRIVATE_KEY || "").trim();

  const res = await fetch(`https://production.wompi.co/v1/transactions/${transactionId}`, {
    method: "GET",
    headers: privateKey
      ? {
          Authorization: `Bearer ${privateKey}`,
          "Content-Type": "application/json",
        }
      : {
          "Content-Type": "application/json",
        },
    cache: "no-store",
  });

  const raw = await res.text();
  let json: any = null;

  try {
    json = raw ? JSON.parse(raw) : null;
  } catch {
    json = null;
  }

  if (!res.ok) {
    throw new Error(
      `No se pudo verificar la transacción en Wompi (${res.status}): ${raw || "sin detalle"}`
    );
  }

  const tx = json?.data;
  if (!tx || typeof tx !== "object") {
    throw new Error("Respuesta inválida de Wompi al verificar la transacción.");
  }

  return tx as WompiTransaction;
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);

    if (!body || typeof body !== "object") {
      return NextResponse.json({ ok: true });
    }

    const eventName = getEventName(body);
    const transactionId = getTransactionId(body);

    await dbInsertLog({
      level: "info",
      scope: "wompi.webhook",
      message: "Webhook recibido",
      meta: {
        eventName,
        transactionId,
      },
    });

    if (eventName && eventName !== "transaction.updated") {
      return NextResponse.json({ ok: true });
    }

    if (!transactionId) {
      await dbInsertLog({
        level: "warn",
        scope: "wompi.webhook",
        message: "Webhook sin transactionId",
        meta: body,
      });

      return NextResponse.json({ ok: true });
    }

    const tx = await fetchTransactionFromWompi(transactionId);

    const reference = String(tx.reference || "").trim();
    const wompiStatus = String(tx.status || "").toUpperCase();
    const appStatus = mapWompiStatus(wompiStatus);
    const amount = Number(tx.amount_in_cents || 0) / 100;
    const shipping = tx.shipping_address || null;

    if (!reference) {
      throw new Error("La transacción verificada en Wompi no trae reference.");
    }

    const existingOrder = await dbGetOrderByCode(reference);
    const wasAlreadyPaid = String(existingOrder?.status || "").toLowerCase() === "paid";

    if (wompiStatus === "APPROVED" && !wasAlreadyPaid) {
      const rawOrderItems = Array.isArray(existingOrder?.items) ? existingOrder.items : [];
      const orderItems = sanitizeOrderItems(rawOrderItems);

      if (!orderItems.length) {
        throw new Error(`La orden ${reference} no tiene items válidos para descontar stock.`);
      }

      try {
        await consumeExcelReservationAndDecrement(reference, orderItems);
      } catch {
        await decrementExcelStock(orderItems);
      }

      await dbInsertLog({
        level: "info",
        scope: "wompi.webhook",
        message: "Stock descontado del Excel consumiendo reserva",
        order_id: reference,
        meta: {
          transactionId,
          items: orderItems,
        },
      });
    }

    if (
      (wompiStatus === "DECLINED" || wompiStatus === "VOIDED" || wompiStatus === "ERROR") &&
      !wasAlreadyPaid
    ) {
      await releaseExcelReservation(reference);

      await dbInsertLog({
        level: "warn",
        scope: "wompi.webhook",
        message: "Reserva de stock liberada por pago no aprobado",
        order_id: reference,
        meta: {
          transactionId,
          wompiStatus,
        },
      });
    }

    await dbUpsertOrder({
      order_code: reference,
      wompi_reference: reference,
      status: appStatus,
      total_amount: Number.isFinite(amount) ? amount : null,
      currency: tx.currency || "COP",
      customer_name: shipping?.name || null,
      customer_email: tx.customer_email || null,
      phone: shipping?.phone_number || null,
      country: shipping?.country || null,
      city: shipping?.city || null,
      address: shipping?.address_line_1 || null,
      provider: "wompi",
      payment_id: transactionId,
      paid_at: wompiStatus === "APPROVED" ? new Date().toISOString() : null,
    });

    try {
      await syncDashboardPaymentData({
        reference,
        transactionId,
        eventName,
        wompiStatus,
        tx,
        orderId: String(existingOrder?.id || "").trim() || null,
      });
    } catch (syncError: any) {
      await dbInsertLog({
        level: "warn",
        scope: "wompi.webhook",
        message: "No se pudo sincronizar payments/payment_events para dashboard",
        order_id: reference,
        meta: {
          transactionId,
          wompiStatus,
          error: syncError?.message || null,
        },
      });
    }

    await dbInsertLog({
      level: wompiStatus === "APPROVED" ? "info" : "warn",
      scope: "wompi.webhook",
      message:
        wompiStatus === "APPROVED"
          ? "Pago aprobado por Wompi"
          : `Cambio de estado Wompi: ${wompiStatus}`,
      order_id: reference,
      meta: {
        transactionId,
        wompiStatus,
        appStatus,
        amount_in_cents: tx.amount_in_cents || null,
        currency: tx.currency || null,
        shipping_address_line_1: shipping?.address_line_1 || null,
        shipping_region: shipping?.region || null,
        skippedStockDiscountBecauseAlreadyPaid: wasAlreadyPaid,
      },
    });

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    try {
      await dbInsertLog({
        level: "error",
        scope: "wompi.webhook",
        message: e?.message || "Error procesando webhook de Wompi",
        meta: {
          stack: e?.stack || null,
        },
      });
    } catch {}

    return NextResponse.json({ ok: true });
  }
}
