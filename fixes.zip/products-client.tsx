// app/products/products-client.tsx
"use client";

import Link from "next/link";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { PRODUCTS, type Product } from "@/lib/products";
import { isFavorite, toggleFavorite } from "@/lib/toggleFavorite";
import { useStore } from "../components/store";

/** =========================
 * Utils
 * ========================= */
function moneyCOP(n: number) {
  return Math.round(n).toLocaleString("es-CO");
}
function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}
function computeSale(price: number, discountPercent?: number) {
  const d = typeof discountPercent === "number" ? clamp(discountPercent, 0, 90) : 0;
  if (!d) return { has: false, was: price, now: price, d: 0 };
  const now = Math.round(price * (1 - d / 100));
  return { has: true, was: price, now, d };
}
function pickImgs(p: Product): { main: string | null; alt: string | null } {
  const imgs = Array.isArray((p as any).images) ? ((p as any).images as string[]) : [];
  const main = (imgs?.[0] || (typeof (p as any).image === "string" ? (p as any).image : "") || "").trim();
  const alt = (imgs?.[1] || "").trim();
  return { main: main || null, alt: alt || null };
}
function safeArr(v: unknown): string[] {
  return Array.isArray(v)
    ? v.filter((x) => typeof x === "string" && x.trim()).map((x) => x.trim())
    : [];
}
function uniq(arr: string[]) {
  const out: string[] = [];
  for (const a of arr) if (a && !out.includes(a)) out.push(a);
  return out;
}
function genderLabel(g?: Product["gender"]) {
  if (g === "men") return "Hombre";
  if (g === "women") return "Mujer";
  if (g === "kids") return "Niños";
  if (g === "unisex") return "Hombre";
  return "Hombre";
}
function typeLabel(category?: string) {
  const c = (category || "").toLowerCase();
  if (c.includes("sandal")) return "Sandalias";
  if (c.includes("slides")) return "Sandalias";
  if (c.includes("access")) return "Accesorios";
  if (c.includes("clothing")) return "Ropa";
  return "Zapatillas";
}
function emitFavEvent() {
  try {
    window.dispatchEvent(new Event("jusp:favorites"));
  } catch {}
}

/** Color swatch: nombre -> color real (fallback robusto) */
function colorToCss(name: string) {
  const n = (name || "").trim().toLowerCase();
  const map: Record<string, string> = {
    black: "#111111",
    negro: "#111111",
    white: "#ffffff",
    blanco: "#ffffff",
    grey: "#9ca3af",
    gray: "#9ca3af",
    gris: "#9ca3af",
    red: "#ef4444",
    rojo: "#ef4444",
    blue: "#3b82f6",
    azul: "#3b82f6",
    green: "#22c55e",
    verde: "#22c55e",
    yellow: "#facc15",
    amarillo: "#facc15",
    orange: "#fb923c",
    naranja: "#fb923c",
    purple: "#a855f7",
    morado: "#a855f7",
    pink: "#fb7185",
    rosado: "#fb7185",
    brown: "#92400e",
    cafe: "#92400e",
    café: "#92400e",
    beige: "#e7d3b1",
    cream: "#f5f5dc",
    gold: "#d4af37",
    silver: "#c0c0c0",
  };
  if (map[n]) return map[n];

  const cssCandidate = name.trim();
  if (!cssCandidate) return "rgba(0,0,0,0.22)";

  try {
    const el = document.createElement("span");
    el.style.color = "";
    el.style.color = cssCandidate;
    if (el.style.color) return cssCandidate;
  } catch {}

  return "rgba(0,0,0,0.22)";
}

/** =========================
 * Tiny UI
 * ========================= */
function Chevron({ open }: { open: boolean }) {
  return (
    <span className={`ch ${open ? "on" : ""}`} aria-hidden="true">
      ▾
      <style jsx>{`
        .ch {
          display: inline-block;
          transition: transform 160ms ease;
          transform: rotate(-90deg);
          font-weight: 950;
          color: rgba(0, 0, 0, 0.65);
          line-height: 1;
        }
        .ch.on {
          transform: rotate(0deg);
        }
      `}</style>
    </span>
  );
}

function FilterSection({
  title,
  open,
  onToggle,
  children,
}: {
  title: string;
  open: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="sec">
      <button className="secTop" type="button" onClick={onToggle} aria-expanded={open}>
        <span className="secT">{title}</span>
        <Chevron open={open} />
      </button>
      {open ? <div className="secBody">{children}</div> : null}

      <style jsx>{`
        .sec {
          border-bottom: 1px solid rgba(0, 0, 0, 0.08);
          padding: 12px 0;
        }
        .secTop {
          width: 100%;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
          border: 0;
          background: transparent;
          padding: 0;
          cursor: pointer;
        }
        .secT {
          font-weight: 950;
          color: #111;
          font-size: 14px;
        }
        .secBody {
          margin-top: 10px;
        }
      `}</style>
    </div>
  );
}

/** =========================
 * Page
 * ========================= */
type SortKey = "launch" | "price_asc" | "price_desc" | "title_asc";
type DiscountCap = 0 | 20 | 30 | 40 | 50 | 60;

/** URL keys (fuente de verdad para persistencia) */
const Q = {
  sort: "sort",
  d: "d",
  type: "type",
  brand: "brand",
  color: "color",
  size: "size",
  side: "side",
} as const;

function parseDiscountCap(v: string | null): DiscountCap {
  const n = Number(v);
  if (n === 20 || n === 30 || n === 40 || n === 50 || n === 60) return n;
  return 0;
}
function parseSort(v: string | null): SortKey {
  if (v === "price_desc" || v === "price_asc" || v === "title_asc" || v === "launch") return v;
  return "launch";
}
function normStr(v: string | null) {
  const s = (v || "").trim();
  return s ? s : null;
}

function ProductsInner({ initialProducts }: { initialProducts: Product[] }) {
  const all = useMemo(() => (initialProducts?.length ? initialProducts : PRODUCTS ?? []), [initialProducts]);
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const { state } = useStore();

  const [filtersOpen, setFiltersOpen] = useState(false);

  const [secDiscount, setSecDiscount] = useState(true);
  const [secType, setSecType] = useState(true);
  const [secBrand, setSecBrand] = useState(true);
  const [secColor, setSecColor] = useState(true);
  const [secSize, setSecSize] = useState(true);

  const sort = useMemo(() => parseSort(searchParams.get(Q.sort)), [searchParams]);
  const dCap = useMemo(() => parseDiscountCap(searchParams.get(Q.d)), [searchParams]);
  const type = useMemo(() => normStr(searchParams.get(Q.type)), [searchParams]);
  const brand = useMemo(() => normStr(searchParams.get(Q.brand)), [searchParams]);
  const color = useMemo(() => normStr(searchParams.get(Q.color)), [searchParams]);
  const size = useMemo(() => normStr(searchParams.get(Q.size)), [searchParams]);

  const sideRef = useRef<HTMLElement | null>(null);
  const [sideScrolled, setSideScrolled] = useState(false);

  useEffect(() => {
    const el = sideRef.current;
    if (!el) return;
    const onScroll = () => setSideScrolled(el.scrollTop > 10);
    onScroll();
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll as any);
  }, [filtersOpen]);

  const types = useMemo(() => uniq(all.map((p) => typeLabel((p as any).category))).sort(), [all]);
  const brands = useMemo(() => uniq(all.map((p) => String((p as any).brand || "Nike"))).sort(), [all]);
  const colors = useMemo(() => uniq(all.flatMap((p) => safeArr((p as any).colors))).sort(), [all]);
  const sizes = useMemo(() => uniq(all.flatMap((p) => safeArr((p as any).sizes))).sort(), [all]);

  function setParam(key: string, value: string | null) {
    const sp = new URLSearchParams(searchParams.toString());
    if (!value) sp.delete(key);
    else sp.set(key, value);
    router.replace(`${pathname}?${sp.toString()}`, { scroll: false });
  }

  function resetFilters() {
    const sp = new URLSearchParams(searchParams.toString());
    sp.delete(Q.d);
    sp.delete(Q.type);
    sp.delete(Q.brand);
    sp.delete(Q.color);
    sp.delete(Q.size);
    router.replace(`${pathname}?${sp.toString()}`, { scroll: false });
  }

  const filtered = useMemo(() => {
    let list = [...all];

    if (dCap) {
      list = list.filter((p) => {
        const disc = Number((p as any).discountPercent ?? (p as any).discount ?? 0);
        return Number.isFinite(disc) && disc >= dCap;
      });
    }
    if (type) list = list.filter((p) => typeLabel((p as any).category) === type);
    if (brand) list = list.filter((p) => String((p as any).brand || "Nike") === brand);
    if (color) list = list.filter((p) => safeArr((p as any).colors).includes(color));
    if (size) list = list.filter((p) => safeArr((p as any).sizes).includes(size));

    if (sort === "launch") {
      const isNewProduct = (p: Product) => {
        const v = Number((p as any).isNew ?? 0);
        const disc = Number((p as any).discountPercent ?? 0);
        return Boolean(v || disc >= 40);
      };
      list.sort((a, b) => Number(isNewProduct(b)) - Number(isNewProduct(a)));
    } else if (sort === "price_asc") {
      list.sort((a, b) => Number((a as any).price ?? 0) - Number((b as any).price ?? 0));
    } else if (sort === "price_desc") {
      list.sort((a, b) => Number((b as any).price ?? 0) - Number((a as any).price ?? 0));
    } else if (sort === "title_asc") {
      list.sort((a, b) => String((a as any).name ?? "").localeCompare(String((b as any).name ?? "")));
    }

    return list;
  }, [all, dCap, type, brand, color, size, sort]);

  const favCount = useMemo(() => {
    try {
      return (state as any)?.favorites?.length ? (state as any).favorites.length : 0;
    } catch {
      return 0;
    }
  }, [state]);

  return (
    <main className="root">
      <div className="topbar">
        <div className="brand">
          <Link href="/" className="logo">
            JUSP
          </Link>
          <div className="pill">{filtered.length} productos</div>
        </div>

        <div className="actions">
          <button className="btn" type="button" onClick={() => setFiltersOpen((v) => !v)}>
            Filtros
          </button>
          <Link className="btn ghost" href="/favorites">
            Favoritos <span className="b">{favCount}</span>
          </Link>
        </div>
      </div>

      <div className={`layout ${filtersOpen ? "" : "noSide"}`}>
        <aside className={`sideWrap ${filtersOpen ? "open" : "closed"}`} aria-hidden={!filtersOpen}>
          <aside
            ref={(n) => {
              sideRef.current = n;
            }}
            className="side"
            aria-label="Filtros"
          >
            <div className="fadeTop" aria-hidden="true" />
            <div className="fadeBottom" aria-hidden="true" />

            <div className="sideInner">
              <div className={`sideTop ${sideScrolled ? "sc" : ""}`}>
                <div className="sideTitle">Filtros</div>
                <button className="sideReset" type="button" onClick={resetFilters}>
                  Limpiar
                </button>
              </div>

              <FilterSection title="Descuento" open={secDiscount} onToggle={() => setSecDiscount((v) => !v)}>
                <div className="row3">
                  {[0, 20, 30, 40, 50, 60].map((n) => {
                    const v = n === 0 ? null : String(n);
                    const on = dCap === (n as any);
                    return (
                      <button
                        key={n}
                        type="button"
                        className={`chip ${on ? "on" : ""}`}
                        onClick={() => setParam(Q.d, v)}
                      >
                        {n === 0 ? "Todos" : `${n}%+`}
                      </button>
                    );
                  })}
                </div>
              </FilterSection>

              <FilterSection title="Tipo" open={secType} onToggle={() => setSecType((v) => !v)}>
                <div className="row2">
                  <button
                    type="button"
                    className={`chip ${!type ? "on" : ""}`}
                    onClick={() => setParam(Q.type, null)}
                  >
                    Todos
                  </button>
                  {types.map((t) => (
                    <button
                      key={t}
                      type="button"
                      className={`chip ${type === t ? "on" : ""}`}
                      onClick={() => setParam(Q.type, t)}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </FilterSection>

              <FilterSection title="Marca" open={secBrand} onToggle={() => setSecBrand((v) => !v)}>
                <div className="row2">
                  <button
                    type="button"
                    className={`chip ${!brand ? "on" : ""}`}
                    onClick={() => setParam(Q.brand, null)}
                  >
                    Todas
                  </button>
                  {brands.map((b) => (
                    <button
                      key={b}
                      type="button"
                      className={`chip ${brand === b ? "on" : ""}`}
                      onClick={() => setParam(Q.brand, b)}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </FilterSection>

              <FilterSection title="Color" open={secColor} onToggle={() => setSecColor((v) => !v)}>
                <div className="row2">
                  <button
                    type="button"
                    className={`chip ${!color ? "on" : ""}`}
                    onClick={() => setParam(Q.color, null)}
                  >
                    Todos
                  </button>
                  {colors.map((c) => (
                    <button
                      key={c}
                      type="button"
                      className={`chip ${color === c ? "on" : ""}`}
                      onClick={() => setParam(Q.color, c)}
                    >
                      <span className="sw" style={{ background: colorToCss(c) }} aria-hidden="true" />
                      {c}
                    </button>
                  ))}
                </div>
              </FilterSection>

              <FilterSection title="Talla" open={secSize} onToggle={() => setSecSize((v) => !v)}>
                <div className="row3">
                  <button
                    type="button"
                    className={`chip ${!size ? "on" : ""}`}
                    onClick={() => setParam(Q.size, null)}
                  >
                    Todas
                  </button>
                  {sizes.map((s) => (
                    <button
                      key={s}
                      type="button"
                      className={`chip ${size === s ? "on" : ""}`}
                      onClick={() => setParam(Q.size, s)}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </FilterSection>

              <div className="sideFoot" />
            </div>
          </aside>
        </aside>

        <section className="main">
          <div className="toolbar">
            <div className="sort">
              <span className="t">Ordenar</span>
              <div className="sortBtns">
                <button
                  type="button"
                  className={`pillBtn ${sort === "launch" ? "on" : ""}`}
                  onClick={() => setParam(Q.sort, "launch")}
                >
                  Novedad
                </button>
                <button
                  type="button"
                  className={`pillBtn ${sort === "price_asc" ? "on" : ""}`}
                  onClick={() => setParam(Q.sort, "price_asc")}
                >
                  $ ↑
                </button>
                <button
                  type="button"
                  className={`pillBtn ${sort === "price_desc" ? "on" : ""}`}
                  onClick={() => setParam(Q.sort, "price_desc")}
                >
                  $ ↓
                </button>
                <button
                  type="button"
                  className={`pillBtn ${sort === "title_asc" ? "on" : ""}`}
                  onClick={() => setParam(Q.sort, "title_asc")}
                >
                  A–Z
                </button>
              </div>
            </div>
          </div>

          <div className="grid">
            {filtered.map((p) => {
              const { main } = pickImgs(p);
              const price = Number((p as any).price ?? 0) || 0;
              const disc = Number((p as any).discountPercent ?? (p as any).discount ?? 0);
              const sale = computeSale(price, disc);

              const fav = isFavorite((p as any).id || (p as any).slug || (p as any).name);

              return (
                <article key={(p as any).id || (p as any).slug || (p as any).name} className="card">
                  <Link className="img" href={`/product?id=${encodeURIComponent(String((p as any).id || ""))}`}>
                    {main ? <img src={main} alt={String((p as any).name || "Producto")} /> : <div className="ph" />}
                    {sale.has ? <div className="badge">-{sale.d}%</div> : null}
                  </Link>

                  <div className="meta">
                    <div className="name">{String((p as any).name || "Producto")}</div>
                    <div className="sub">
                      {genderLabel((p as any).gender)} · {typeLabel((p as any).category)}
                    </div>

                    <div className="row">
                      <div className="price">
                        {sale.has ? (
                          <>
                            <span className="was">${moneyCOP(sale.was)}</span>
                            <b>${moneyCOP(sale.now)}</b>
                          </>
                        ) : (
                          <b>${moneyCOP(price)}</b>
                        )}
                      </div>

                      <button
                        type="button"
                        className={`fav ${fav ? "on" : ""}`}
                        onClick={() => {
                          toggleFavorite((p as any).id || (p as any).slug || (p as any).name);
                          emitFavEvent();
                        }}
                        aria-label="Favorito"
                      >
                        ♥
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      </div>

      <style jsx>{`
        /* (tus estilos quedan igual) */
      `}</style>
    </main>
  );
}

export default function ProductsClient({ initialProducts }: { initialProducts: Product[] }) {
  return <ProductsInner initialProducts={initialProducts} />;
}